module.exports=[15934,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_favicon_ico_route_actions_353150a5.js.map